/*
 *
 * Copyright (c) 2020-2021 Shenshu Technologies Co., Ltd.
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 */
/***********************************************************************************
* [bootRam Space] start: 0x04010000, end: 0x0402a000, len: 0x1a000(104k).
* [bss + stack]   start: 0x04010000, end: 0x04010a00, len: 0xa00.
* [ddr init or key area] start: 0x04010a00, end: 0x04024600, len: 0x13c00.
* [malloc] start: 0x04024600, end: 0x04026ca0, len: 0x26a0.
***********************************************************************************/
/* [ddr init or key area] start: 0x04010a00, end: 0x04024600, len: 0x13c00. */
cache(0x8000,   2)	/* ddr init or key area reserved */
cache(0x3c00,   1)	/* ddr init or key area reserved */

/* [malloc] start: 0x04024600, end: 0x04026ca0 , len: 0x26a0 */
cache(0x100,	5)	/* rsa pss */
cache(0x200,	5)	/* usb device; rsa decrypt buf for n=4096 */
cache(0x400,	3)	/* rsa_exp_mod (RSA_KEY_LEN_4096*2) */
cache(0x50,     2)	/* usb device */
cache(0xb00,    1)	/* usb device */
/**********************************************************************************/
/**********************************************************************************/
