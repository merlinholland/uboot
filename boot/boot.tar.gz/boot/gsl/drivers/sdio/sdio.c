/*
 *
 * Copyright (c) 2018-2021 Shenshu Technologies Co., Ltd.
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 */

#include "fat.h"

#define FILE_NAME  "u-boot.bin"

int copy_from_sdio(void *buffer, unsigned long maxsize)
{
	int size;

	size = do_fat_read_at(FILE_NAME,
			      (unsigned char *)buffer, maxsize);
	if (size <= 0)
		return TD_FAILURE;

	return TD_SUCCESS;
}
