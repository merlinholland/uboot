/*
 *
 * Copyright (c) 2019-2021 Shenshu Technologies Co., Ltd.
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 */

#ifndef __SYS_H__
#define __SYS_H__
#include <types.h>
static inline void writel(uint32_t val, unsigned long int addr)
{
	(*(volatile uint32_t *)(addr)) = (val);
}

static inline void writew(uint16_t val, unsigned long int addr)
{
	(*(volatile uint16_t *)(addr)) = (val);
}

static inline void writeb(uint8_t val, unsigned long int addr)
{
	(*(volatile uint8_t *)(addr)) = (val);
}

static inline uint32_t readl(unsigned long int addr)
{
	return (*(volatile uint32_t *)(addr));
}

static inline uint16_t readw(unsigned long int addr)
{
	return (*(volatile uint16_t *)(addr));
}

static inline uint8_t readb(unsigned long int addr)
{
	return (*(volatile uint8_t *)(addr));
}
#endif /* end of __SYS_H__ */
